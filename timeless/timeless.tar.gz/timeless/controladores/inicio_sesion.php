<?php

include ("controladores/conexion.php");
$username = $_POST["username"];

$password = $_POST["password"];
 

if(isset($_POST["entrar"])){
    $query = mysqli_query($con,"SELECT * FROM usuario WHERE usuario = '$username' AND clave = '$password'");
    $nr = mysqli_num_rows($query);
    if($nr==1){

        header("location: ../vistas/principal.html");
        session_start();
        $_SESSION['username'] = $username;
        die();
    }
    else{
        header("location: ../vistas/inicio_sesion.html");
        die();
    }
}

?>
