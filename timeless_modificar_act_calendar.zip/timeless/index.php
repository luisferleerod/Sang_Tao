<?php
	header("location: interfaz/index.html");
?>
