<?php
$dbhost = "192.168.77.45";
$dbuser= "jjosegomez";
$dbpass = "luchopelucho";
$dbname ="sang_tao";
$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if(!$con){ //En caso de que falle, establecer que no hay conexion
    die("No hay conexion: " . mysqli_connect_error());
}

//Envio Datos
if (isset($_SERVER["REQUEST_METHOD"]) && $_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtengo parametros de busqueda
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Preparo consulta
    //$query = "SELECT * FROM usuario WHERE usuario = '$username' AND clave = '$password'";
    $query = "INSERT INTO usuario VALUES ('carlos','1234','carlos')";
    // Envio consulta
    $result = mysqli_query($con, $query);

    // Miro si usuario esta
    if (mysqli_num_rows($result) > 0) {
        // Si se autentica muestra principal
        header("Location: principal.html");
        exit();
    } else {
        // Si no se valida, error
        echo "Invalid username or password.";
    }
}


// Cierro BDD
mysqli_close($con);
?>